# Trabalho P2
Trabalho P2
feito em flask Python Orientado a Objetos
